package entity;

import javax.persistence.*;
import java.util.List;
import java.util.ArrayList;

/**
 * @author Antonio Goncalves
 */
@Entity
@Table(name = "t6_customer")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "DISC", discriminatorType = DiscriminatorType.STRING, length = 15)
public abstract class Customer {

    // ======================================
    // =             Attributes             =
    // ======================================
    @Id
    @GeneratedValue
    private Long id;
    @Column(length = 15)
    protected String telephone;
    @Column(name = "e_mail")
    protected String email;

    // ======================================
    // =    Callback annotated methods      =
    // ======================================

    @PrePersist
    @PreUpdate
    private void validatePhoneNumber() {
        if (telephone == null || "".equals(telephone)) {
            return;
        }
        if (telephone.charAt(0) != '+')
            throw new IllegalArgumentException("Invalid phone number");
    }

    // ======================================
    // =         Getters & Setters          =
    // ======================================
    public Long getId() {
        return id;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}