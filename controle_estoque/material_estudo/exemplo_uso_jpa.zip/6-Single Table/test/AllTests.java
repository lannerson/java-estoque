import entity.*;
import junit.framework.JUnit4TestAdapter;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * @author Antonio Goncalves
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
        IndividualTest.class,
        CompanyTest.class,
        CustomerTest.class
        })
public class AllTests {

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(AllTests.class);
    }
}