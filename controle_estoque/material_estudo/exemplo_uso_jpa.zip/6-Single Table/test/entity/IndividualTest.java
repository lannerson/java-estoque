package entity;

import junit.framework.JUnit4TestAdapter;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @author Antonio Goncalves
 */
public class IndividualTest {
    private static String PERSISTENCE_UNIT_NAME = "watermelonPU";
    private static Calendar calendar;

    private EntityManagerFactory emf;
    private EntityManager em;
    private EntityTransaction trans;

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(IndividualTest.class);
    }

    @BeforeClass
    public static void initCalendar() {
        calendar = GregorianCalendar.getInstance();
    }

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        em = emf.createEntityManager();
        trans = em.getTransaction();
    }

    @After
    public void close() {
        em.close();
        emf.close();
    }

    @Test
    public void createIndividual() {
        calendar.set(1940, 10, 9);
        Date dateOfBirth = calendar.getTime();
        Individual individual = new Individual("John", "Lennon", "+411909", "john@lenon.com", dateOfBirth);

        // Creates an individual
        trans.begin();
        em.persist(individual);
        trans.commit();
        Long individualId = individual.getId();

        // Finds the individual by primary key
        individual = em.find(Individual.class, individualId);
        assertEquals(individual.getEmail(), "john@lenon.com");
        assertEquals(individual.getAge(), 66);

        // Updates the individual
        trans.begin();
        individual.setEmail("john@beatles.co.uk");
        trans.commit();

        // Finds the individual by primary key
        individual = em.find(Individual.class, individualId);
        assertEquals(individual.getEmail(), "john@beatles.co.uk");
        assertEquals(individual.getAge(), 66);

        // Deletes the individual
        trans.begin();
        em.remove(individual);
        trans.commit();

        assertNull("individual should have been deleted", em.find(Individual.class, individualId));
    }

    @Test(expected = IllegalArgumentException.class)
    public void createIndividualWithInvalidPhone() {
        calendar.set(1940, 10, 9);
        Date dateOfBirth = calendar.getTime();
        Individual individual = new Individual("John", "Lennon", "411909", "john@lenon.com", dateOfBirth);

        // Creates an individual
        trans.begin();
        em.persist(individual);
        trans.commit();
    }

    @Test
    public void findIndividuals() {
        calendar.set(1940, 10, 9);
        Individual individual1 = new Individual("John", "Lennon", "+411909", "john@lenon.com", calendar.getTime());
        calendar.set(1940, 7, 7);
        Individual individual2 = new Individual("Ringo", "Starr", "+187445", "ringo@star.com", calendar.getTime());
        calendar.set(1943, 2, 25);
        Individual individual3 = new Individual("Georges", "Harrison", "+44877899", "georges@harrison.com", calendar.getTime());
        calendar.set(1942, 6, 18);
        Individual individual4 = new Individual("Paul", "McCartney", "+41871109", "paul@mccartney.com", calendar.getTime());

        // Creates the individuals
        trans.begin();
        em.persist(individual1);
        em.persist(individual2);
        em.persist(individual3);
        em.persist(individual4);
        trans.commit();

        Query query;
        List<Individual> individuals;

        // Finds all the individuals
        query = em.createQuery("SELECT i FROM Individual i");
        individuals = query.getResultList();
        assertEquals(individuals.size(), 4);

        // Finds all the individuals ordered by lastname
        query = em.createQuery("SELECT i FROM Individual i ORDER BY i.lastname");
        individuals = query.getResultList();
        assertEquals(individuals.size(), 4);

        // Finds all the individuals with a name = Ringo
        query = em.createQuery("SELECT i FROM Individual i WHERE i.firstname='John'");
        individuals = query.getResultList();
        assertEquals(individuals.size(), 1);

        // Finds all the individuals with a name containing "Mc" or MC
        query = em.createQuery("SELECT i FROM Individual i WHERE UPPER(i.lastname) LIKE :keyword");
        query.setParameter("keyword", "%MC%");
        individuals = query.getResultList();
        assertEquals(individuals.size(), 1);

        // Deletes the individuals
        trans.begin();
        em.remove(individual1);
        em.remove(individual2);
        em.remove(individual3);
        em.remove(individual4);
        trans.commit();
    }
}