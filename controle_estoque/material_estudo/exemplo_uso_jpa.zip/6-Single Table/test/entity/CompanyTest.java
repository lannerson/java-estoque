package entity;

import junit.framework.JUnit4TestAdapter;
import org.junit.After;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @author Antonio Goncalves
 */
public class CompanyTest {
    private static String PERSISTENCE_UNIT_NAME = "watermelonPU";
    private static Calendar calendar;

    private EntityManagerFactory emf;
    private EntityManager em;
    private EntityTransaction trans;

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(CompanyTest.class);
    }

    @BeforeClass
    public static void initCalendar() {
        calendar = GregorianCalendar.getInstance();
    }

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        em = emf.createEntityManager();
        trans = em.getTransaction();
    }

    @After
    public void close() {
        em.close();
        emf.close();
    }

    @Test
    public void createCompany() {
        Company company = new Company("Universal", "Mr Universe", 50000, "+154888454", "contact@universal.com");

        // Creates an company
        trans.begin();
        em.persist(company);
        trans.commit();
        Long companyId = company.getId();

        // Finds the company by primary key
        company = em.find(Company.class, companyId);
        assertEquals(company.getEmail(), "contact@universal.com");

        // Updates the company
        trans.begin();
        company.setEmail("info@universal.com");
        trans.commit();

        // Finds the company by primary key
        company = em.find(Company.class, companyId);
        assertEquals(company.getEmail(), "info@universal.com");

        // Deletes the company
        trans.begin();
        em.remove(company);
        trans.commit();

        assertNull("Company should have been deleted", em.find(Company.class, companyId));
    }

    @Test(expected = IllegalArgumentException.class)
    public void createCompanyWithInvalidPhone() {
        Company company = new Company("Universal", "Mr Universe", 50000, "154888454", "contact@universal.com");

        // Creates an company
        trans.begin();
        em.persist(company);
        trans.commit();
    }

    @Test
    public void findCompanys() {
        Company company1 = new Company("Universal", "Mr Universe", 50000, "+154888454", "contact@universal.com");
        Company company2 = new Company("Sony", "Mr Father", 25000, "+14519454", "contact@sony.com");
        Company company3 = new Company("Warner", "Mr Bross", 10000, "+15465161454", "contact@warner.com");
        Company company4 = new Company("BMG", "Mr BMW", 10000, "+44515484", "contact@bmg.com");

        // Creates the companys
        trans.begin();
        em.persist(company1);
        em.persist(company2);
        em.persist(company3);
        em.persist(company4);
        trans.commit();

        Query query;
        List<Company> companys;

        // Finds all the companys
        query = em.createQuery("SELECT c FROM Company c");
        companys = query.getResultList();
        assertEquals(companys.size(), 4);

        // Finds all the companys ordered by lastname
        query = em.createQuery("SELECT c FROM Company c ORDER BY c.name");
        companys = query.getResultList();
        assertEquals(companys.size(), 4);

        // Finds all the companys with a name = Ringo
        query = em.createQuery("SELECT c FROM Company c WHERE c.name='BMG'");
        companys = query.getResultList();
        assertEquals(companys.size(), 1);

        // Finds all the companys with more than 10000 employees
        query = em.createQuery("SELECT c FROM Company c WHERE c.numberOfEmployees > 10000");
        companys = query.getResultList();
        assertEquals(companys.size(), 2);

        // Finds all the companys with a number of employees between 10000 and 50000
        query = em.createQuery("SELECT c FROM Company c WHERE c.numberOfEmployees BETWEEN 10000 and 50000");
        companys = query.getResultList();
        assertEquals(companys.size(), 4);

        // Finds all the companys with a number of employees between 10001 and 49999
        query = em.createQuery("SELECT c FROM Company c WHERE c.numberOfEmployees BETWEEN 10001 and 49999");
        companys = query.getResultList();
        assertEquals(companys.size(), 1);

        // Deletes the companys
        trans.begin();
        em.remove(company1);
        em.remove(company2);
        em.remove(company3);
        em.remove(company4);
        trans.commit();
    }
}