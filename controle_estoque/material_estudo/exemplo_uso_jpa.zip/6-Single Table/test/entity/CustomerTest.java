package entity;

import junit.framework.JUnit4TestAdapter;
import org.junit.*;

import javax.persistence.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @author Antonio Goncalves
 */
public class CustomerTest {
    private static String PERSISTENCE_UNIT_NAME = "watermelonPU";
    private static Calendar calendar;

    private EntityManagerFactory emf;
    private EntityManager em;
    private EntityTransaction trans;

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(CustomerTest.class);
    }

    @BeforeClass
    public static void initCalendar() {
        calendar = GregorianCalendar.getInstance();
    }

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        em = emf.createEntityManager();
        trans = em.getTransaction();
    }

    @After
    public void close() {
        em.close();
        emf.close();
    }

    @Test(expected = Exception.class)
    public void wrongQueries() {
        Query query;
        List<Customer> customers;

        // There is no lastname in customer
        query = em.createQuery("SELECT c FROM Customer c WHERE c.lastname='John'");
        customers = query.getResultList();
    }

    @Test
    public void findCustomers() {

        // Companies
        Company company1 = new Company("Universal", "Mr Universe", 50000, "+154888454", "contact@universal.com");
        Company company2 = new Company("Sony", "Mr Father", 25000, "+14519454", "contact@sony.com");
        Company company3 = new Company("Warner", "Mr Bross", 10000, "+15465161454", "contact@warner.com");
        Company company4 = new Company("BMG", "Mr BMW", 10000, "+44515484", "contact@bmg.com");

        // Creates the companys
        trans.begin();
        em.persist(company1);
        em.persist(company2);
        em.persist(company3);
        em.persist(company4);
        trans.commit();

        // Individuals
        calendar.set(1940, 10, 9);
        Individual individual1 = new Individual("John", "Lennon", "+411909", "john@lenon.com", calendar.getTime());
        calendar.set(1940, 7, 7);
        Individual individual2 = new Individual("Ringo", "Starr", "+187445", "ringo@star.com", calendar.getTime());
        calendar.set(1943, 2, 25);
        Individual individual3 = new Individual("Georges", "Harrison", "+44877899", "georges@harrison.com", calendar.getTime());
        calendar.set(1942, 6, 18);
        Individual individual4 = new Individual("Paul", "McCartney", "+41871109", "paul@mccartney.com", calendar.getTime());

        // Creates the individuals
        trans.begin();
        em.persist(individual1);
        em.persist(individual2);
        em.persist(individual3);
        em.persist(individual4);
        trans.commit();

        Query query;
        List<Customer> customers;

        // Finds all the companies
        query = em.createQuery("SELECT c FROM Company c");
        customers = query.getResultList();
        Assert.assertEquals(customers.size(), 4);

        // Finds all the individuals
        query = em.createQuery("SELECT i FROM Individual i");
        customers = query.getResultList();
        Assert.assertEquals(customers.size(), 4);

        // Finds all the customers
        query = em.createQuery("SELECT c FROM Customer c");
        customers = query.getResultList();
        Assert.assertEquals(customers.size(), 8);

        // Deletes the companys
        trans.begin();
        em.remove(company1);
        em.remove(company2);
        em.remove(company3);
        em.remove(company4);
        trans.commit();

        // Deletes the individuals
        trans.begin();
        em.remove(individual1);
        em.remove(individual2);
        em.remove(individual3);
        em.remove(individual4);
        trans.commit();
    }
}