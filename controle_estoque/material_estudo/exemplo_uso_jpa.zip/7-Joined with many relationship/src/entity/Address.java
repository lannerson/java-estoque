package entity;

import javax.persistence.*;
import java.util.List;
import java.util.ArrayList;

/**
 * @author Antonio Goncalves
 */
@Entity
@Table(name = "t7_address")
public class Address {

    // ======================================
    // =             Attributes             =
    // ======================================
    @Id
    @GeneratedValue
    private Long id;
    private String street;
    @Column(length = 100)
    private String city;
    @Column(name = "zip_code", length = 10)
    private String zipcode;
    @Column(length = 50)
    private String country;

    @ManyToMany(cascade = CascadeType.PERSIST)
    @JoinTable(name = "t7_address_tag",
            joinColumns = {@JoinColumn(name = "address_fk")},
            inverseJoinColumns = {@JoinColumn(name = "tag_fk")})
    private List<Tag> tags = new ArrayList<Tag>();
    
    // ======================================
    // =            Constructors            =
    // ======================================

    public Address() {
    }


    public Address(String street, String city, String zipcode, String country) {
        this.street = street;
        this.city = city;
        this.zipcode = zipcode;
        this.country = country;
    }

    // ======================================
    // =         Getters & Setters          =
    // ======================================

    public Long getId() {
        return id;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public List<Tag> getTags() {
        return tags;
    }

    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }

    public void addTag(Tag tag) {
        tags.add(tag);
    }
}