package entity;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @author Antonio Goncalves
 */
@Entity
@Table(name = "t7_individual")
@DiscriminatorValue("indiv") // If omitted the value is the name of the class
public class Individual extends Customer {

    // ======================================
    // =             Attributes             =
    // ======================================
    @Column(nullable = false)
    private String firstname;
    @Column(nullable = false, length = 30)
    private String lastname;
    @Column(name = "date_of_birth")
    @Temporal(TemporalType.DATE)
    private Date dateOfBirth;
    @Transient
    private Integer age;

    // ======================================
    // =            Constructors            =
    // ======================================

    public Individual() {
    }

    public Individual(String firstname, String lastname, String telephone, String email, Date dateOfBirth) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.telephone = telephone;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
    }

    // ======================================
    // =    Callback annotated methods      =
    // ======================================
    /**
     * Calculates the customer's age.
     */
    @PostLoad
    @PostPersist
    @PostUpdate
    private void calculateAge() {
        if (dateOfBirth == null) {
            age = null;
            return;
        }

        Calendar birth = new GregorianCalendar();
        birth.setTime(dateOfBirth);
        Calendar now = new GregorianCalendar();
        now.setTime(new Date());
        int adjust = 0;
        if (now.get(Calendar.DAY_OF_YEAR) - birth.get(Calendar.DAY_OF_YEAR) < 0) {
            adjust = -1;
        }
        age = now.get(Calendar.YEAR) - birth.get(Calendar.YEAR) + adjust;
    }

    // ======================================
    // =         Getters & Setters          =
    // ======================================

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Integer getAge() {
        return age;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
}