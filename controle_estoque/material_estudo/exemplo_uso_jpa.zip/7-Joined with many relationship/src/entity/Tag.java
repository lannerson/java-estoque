package entity;

import javax.persistence.*;
import java.util.List;

/**
 * @author Antonio Goncalves
 */
@Entity
@Table(name = "t7_tag")
public class Tag {

    // ======================================
    // =             Attributes             =
    // ======================================
    @Id
    private String name;

    @ManyToMany  // this annotation can be omitted
    private List<Address> addresses;

    // ======================================
    // =            Constructors            =
    // ======================================

    public Tag() {
    }


    public Tag(String name) {
        this.name = name;
    }

    // ======================================
    // =         Getters & Setters          =
    // ======================================

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<Address> addresses) {
        this.addresses = addresses;
    }
}