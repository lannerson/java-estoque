package entity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author Antonio Goncalves
 */
@Entity
@Table(name = "t7_company")
@DiscriminatorValue("comp") // If omitted the value is the name of the class
public class Company extends Customer {

    // ======================================
    // =             Attributes             =
    // ======================================
    @Column(nullable = false)
    private String name;
    private String contactName;
    @Column(name = "nb_employees")
    private Integer numberOfEmployees;

    // ======================================
    // =            Constructors            =
    // ======================================

    public Company() {
    }


    public Company(String name, String contactName, Integer numberOfEmployees, String telephone, String email) {
        this.name = name;
        this.contactName = contactName;
        this.numberOfEmployees = numberOfEmployees;
        this.telephone = telephone;
        this.email = email;
    }

    // ======================================
    // =         Getters & Setters          =
    // ======================================

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getNumberOfEmployees() {
        return numberOfEmployees;
    }

    public void setNumberOfEmployees(Integer numberOfEmployees) {
        this.numberOfEmployees = numberOfEmployees;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }
}