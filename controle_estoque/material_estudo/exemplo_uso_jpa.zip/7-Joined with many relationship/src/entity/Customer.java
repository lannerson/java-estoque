package entity;

import javax.persistence.*;
import java.util.List;
import java.util.ArrayList;

/**
 * @author Antonio Goncalves
 */
@Entity
@Table(name = "t7_customer")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "DISC", discriminatorType = DiscriminatorType.STRING, length = 5) // If omitted the column is called DTYPE
public abstract class Customer {

    // ======================================
    // =             Attributes             =
    // ======================================
    @Id
    @GeneratedValue
    private Long id;
    @Column(length = 15)
    protected String telephone;
    @Column(name = "e_mail")
    protected String email;
    @OneToOne(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST, CascadeType.REMOVE})
    @JoinColumn(name = "home_address_fk", nullable = false)
    private Address homeAddress;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinTable(name = "t7_delivery_addresses",
            joinColumns = {@JoinColumn(name = "customer_fk")},
            inverseJoinColumns = {@JoinColumn(name = "address_fk")})
    private List<Address> deliveryAddresses = new ArrayList<Address>();

    // ======================================
    // =    Callback annotated methods      =
    // ======================================

    @PrePersist
    @PreUpdate
    private void validatePhoneNumber() {
        if (telephone == null || "".equals(telephone)) {
            return;
        }
        if (telephone.charAt(0) != '+')
            throw new IllegalArgumentException("Invalid phone number");
    }

    // ======================================
    // =         Getters & Setters          =
    // ======================================
    public Long getId() {
        return id;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Address getHomeAddress() {
        return homeAddress;
    }

    public void setHomeAddress(Address homeAddress) {
        this.homeAddress = homeAddress;
    }

    public List<Address> getDeliveryAddresses() {
        return deliveryAddresses;
    }

    public void setDeliveryAddresses(List<Address> deliveryAddresses) {
        this.deliveryAddresses = deliveryAddresses;
    }

    public void addDeliveryAddress(Address deliveryAddress) {
        deliveryAddresses.add(deliveryAddress);
    }
}