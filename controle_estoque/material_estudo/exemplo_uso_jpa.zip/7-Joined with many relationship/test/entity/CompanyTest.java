package entity;

import junit.framework.JUnit4TestAdapter;
import org.junit.After;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @author Antonio Goncalves
 */
public class CompanyTest {
    private static String PERSISTENCE_UNIT_NAME = "watermelonPU";
    private static Calendar calendar;

    private EntityManagerFactory emf;
    private EntityManager em;
    private EntityTransaction trans;

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(CompanyTest.class);
    }

    @BeforeClass
    public static void initCalendar() {
        calendar = GregorianCalendar.getInstance();
    }

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        em = emf.createEntityManager();
        trans = em.getTransaction();
    }

    @After
    public void close() {
        em.close();
        emf.close();
    }

    @Test(expected = Exception.class)
    public void createCompanyWithoutAddress() {
        Company company = new Company("Universal", "Mr Universe", 50000, "+154888454", "contact@universal.com");

        // Creates an company
        trans.begin();
        em.persist(company);
        trans.commit();
    }

    @Test
    public void createCompanyWithAddress() {
        Company company = new Company("Universal", "Mr Universe", 50000, "+154888454", "contact@universal.com");
        Address homeAddress = new Address("World Street", "New York", "7448", "UK");
        company.setHomeAddress(homeAddress);

        // Creates an company
        trans.begin();
        em.persist(company);
        trans.commit();
        Long companyId = company.getId();
        Long addressId = homeAddress.getId();

        // Finds the company by primary key
        company = em.find(Company.class, companyId);
        assertEquals(company.getEmail(), "contact@universal.com");
        assertEquals(company.getHomeAddress().getCountry(), "UK");

        // Updates the company
        trans.begin();
        company.setEmail("info@universal.com");
        homeAddress.setCountry("US");
        trans.commit();

        // Finds the company by primary key
        company = em.find(Company.class, companyId);
        assertEquals(company.getEmail(), "info@universal.com");
        assertEquals(company.getHomeAddress().getCountry(), "US");

        // Deletes the company
        trans.begin();
        em.remove(company);
        trans.commit();

        assertNull("Company should have been deleted", em.find(Company.class, companyId));
        assertNull("Address should have been deleted", em.find(Address.class, addressId));
    }

    @Test
    public void createCompanyWithDeliveryAddresses() {
        Company company = new Company("Universal", "Mr Universe", 50000, "+154888454", "contact@universal.com");
        // Home address
        Address homeAddress = new Address("World Street", "New York", "7448", "UK");
        company.setHomeAddress(homeAddress);
        // Delivery addresses
        List<Address> deliveryAddresses = new ArrayList<Address>();
        deliveryAddresses.add(new Address("25 World Street", "New York", "7448", "US"));
        deliveryAddresses.add(new Address("38 Blue Boulevard", "New York", "7897", "US"));
        company.setDeliveryAddresses(deliveryAddresses);

        // Creates a company
        trans.begin();
        em.persist(company);
        trans.commit();
        Long companyId = company.getId();

        // Finds the company by primary key
        company = em.find(Company.class, companyId);
        assertEquals(company.getEmail(), "contact@universal.com");
        assertEquals(company.getHomeAddress().getCountry(), "UK");
        assertEquals(company.getDeliveryAddresses().size(), 2);

        // Deletes the company
        trans.begin();
        em.remove(company);
        trans.commit();

        assertNull("Company should have been deleted", em.find(Company.class, companyId));
    }

    @Test
    public void createCompanyWithTaggedAddresses() {
        Tag tag1 = new Tag("working hours");
        Tag tag2 = new Tag("week-ends");
        Tag tag3 = new Tag("mind the dog");

        // Company
        Company company = new Company("Universal", "Mr Universe", 50000, "+154888454", "contact@universal.com");
        // Tagged Home address
        Address homeAddress = new Address("World Street", "New York", "7448", "UK");
        homeAddress.addTag(tag1);
        homeAddress.addTag(tag2);
        company.setHomeAddress(homeAddress);
        // Tagged Delivery addresses
        Address deliveryAddress1 = new Address("25 World Street", "New York", "7448", "US");
        deliveryAddress1.addTag(tag1);
        Address deliveryAddress2 = new Address("38 Blue Boulevard", "New York", "7897", "US");
        deliveryAddress2.addTag(tag1);
        deliveryAddress2.addTag(tag2);
        deliveryAddress2.addTag(tag3);
        company.addDeliveryAddress(deliveryAddress1);
        company.addDeliveryAddress(deliveryAddress2);

        // Creates a company
        trans.begin();
        em.persist(company);
        trans.commit();
        Long companyId = company.getId();

        // Finds the company by primary key
        company = em.find(Company.class, companyId);
        assertEquals(company.getEmail(), "contact@universal.com");
        assertEquals(company.getHomeAddress().getCountry(), "UK");
        assertEquals(company.getDeliveryAddresses().size(), 2);

        // Makes sure every address is tagged
        for (Address deliveryAddress : company.getDeliveryAddresses()) {
            assertTrue(deliveryAddress.getTags().size() != 0);
        }

        // Deletes the company
        trans.begin();
        em.remove(company);
        trans.commit();

        assertNull("Company should have been deleted", em.find(Company.class, companyId));

        // Deletes the tags
        trans.begin();
        em.remove(tag1);
        em.remove(tag2);
        em.remove(tag3);
        trans.commit();
    }

    @Test(expected = IllegalArgumentException.class)
    public void createCompanyWithInvalidPhone() {
        Company company = new Company("Universal", "Mr Universe", 50000, "154888454", "contact@universal.com");

        // Creates an company
        trans.begin();
        em.persist(company);
        trans.commit();
    }

    @Test
    public void queryCompanys() {
        Company company1 = new Company("Universal", "Mr Universe", 50000, "+154888454", "contact@universal.com");
        company1.setHomeAddress(new Address("World Street", "New York", "7448", "UK"));
        Company company2 = new Company("Sony", "Mr Father", 25000, "+14519454", "contact@sony.com");
        company2.setHomeAddress(new Address("General Alley", "Paris", "75011", "FR"));
        Company company3 = new Company("Warner", "Mr Bross", 10000, "+15465161454", "contact@warner.com");
        company3.setHomeAddress(new Address("Fame Boulevard", "New York", "84487", "US"));
        Company company4 = new Company("BMG", "Mr BMW", 10000, "+44515484", "contact@bmg.com");
        company4.setHomeAddress(new Address("Music Straat", "Berlin", "8542", "GE"));

        // Creates the companys
        trans.begin();
        em.persist(company1);
        em.persist(company2);
        em.persist(company3);
        em.persist(company4);
        trans.commit();

        Query query;
        List<Company> companys;

        // Finds all the companys
        query = em.createQuery("SELECT c FROM Company c");
        companys = query.getResultList();
        assertEquals(companys.size(), 4);

        // Finds all the companys ordered by lastname
        query = em.createQuery("SELECT c FROM Company c ORDER BY c.name");
        companys = query.getResultList();
        assertEquals(companys.size(), 4);

        // Finds all the companys with a name = Ringo
        query = em.createQuery("SELECT c FROM Company c WHERE c.name='BMG'");
        companys = query.getResultList();
        assertEquals(companys.size(), 1);

        // Finds all the companys living in the US
        query = em.createQuery("SELECT c FROM Company c WHERE c.homeAddress.country='US'");
        companys = query.getResultList();
        assertEquals(companys.size(), 1);

        // Finds all the companys living in the US (using parameters)
        query = em.createQuery("SELECT c FROM Company c WHERE c.homeAddress.country=:cnty");
        query.setParameter("cnty", "US");
        companys = query.getResultList();
        assertEquals(companys.size(), 1);

        // Finds all the companys with more than 10000 employees
        query = em.createQuery("SELECT c FROM Company c WHERE c.numberOfEmployees > 10000");
        companys = query.getResultList();
        assertEquals(companys.size(), 2);

        // Finds all the companys with a number of employees between 10000 and 50000
        query = em.createQuery("SELECT c FROM Company c WHERE c.numberOfEmployees BETWEEN 10000 and 50000");
        companys = query.getResultList();
        assertEquals(companys.size(), 4);

        // Finds all the companys with a number of employees between 10001 and 49999
        query = em.createQuery("SELECT c FROM Company c WHERE c.numberOfEmployees BETWEEN 10001 and 49999");
        companys = query.getResultList();
        assertEquals(companys.size(), 1);

        // Finds the maximum number of employees
        query = em.createQuery("SELECT MAX (c.numberOfEmployees) FROM Company c");
        Integer max = (Integer) query.getSingleResult();
        assertEquals(max, 50000);

        // Finds the minimum number of employees
        query = em.createQuery("SELECT MIN (c.numberOfEmployees) FROM Company c");
        Integer min = (Integer) query.getSingleResult();
        assertEquals(min, 10000);

        // Finds the sum of employees
        query = em.createQuery("SELECT SUM (c.numberOfEmployees) FROM Company c");
        Long sum = (Long) query.getSingleResult();
        assertEquals(sum, 95000L);

        // Deletes the companys
        trans.begin();
        em.remove(company1);
        em.remove(company2);
        em.remove(company3);
        em.remove(company4);
        trans.commit();
    }
}