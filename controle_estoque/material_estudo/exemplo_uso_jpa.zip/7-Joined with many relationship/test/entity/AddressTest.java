package entity;

import junit.framework.JUnit4TestAdapter;
import org.junit.After;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.*;
import java.util.List;

/**
 * @author Antonio Goncalves
 */
public class AddressTest {
    private static String PERSISTENCE_UNIT_NAME = "watermelonPU";

    private EntityManagerFactory emf;
    private EntityManager em;
    private EntityTransaction trans;

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(AddressTest.class);
    }

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        em = emf.createEntityManager();
        trans = em.getTransaction();
    }

    @After
    public void close() {
        em.close();
        emf.close();
    }

    @Test
    public void createAddress() {
        Address address = new Address("St James St", "London", "SW14", "UK");

        // Creates an address
        trans.begin();
        em.persist(address);
        trans.commit();
        Long id = address.getId();

        // Finds the address by primary key
        address = em.find(Address.class, id);
        assertEquals(address.getCountry(), "UK");

        // Updates the address
        trans.begin();
        address.setCountry("US");
        trans.commit();

        // Finds the address by primary key
        address = em.find(Address.class, id);
        assertEquals(address.getCountry(), "US");

        // Deletes the address
        trans.begin();
        em.remove(address);
        trans.commit();

        assertNull("Address should has been deleted", em.find(Address.class, id));
    }

    @Test
    public void createTaggedAddress() {
        Tag tag1 = new Tag("working hours");
        Tag tag2 = new Tag("week-ends");
        Tag tag3 = new Tag("mind the dog");
        Address address = new Address("St James St", "London", "SW14", "UK");
        address.addTag(tag1);
        address.addTag(tag2);
        address.addTag(tag3);

        // Creates an address
        trans.begin();
        em.persist(address);
        trans.commit();
        Long id = address.getId();

        // Finds the address by primary key
        address = em.find(Address.class, id);
        assertEquals(address.getCountry(), "UK");
        assertEquals(address.getTags().size(), 3);

        // Deletes the address
        trans.begin();
        em.remove(address);
        trans.commit();

        assertNull("Address should have been deleted", em.find(Address.class, id));
        assertNotNull("Tags should have not been deleted", em.find(Tag.class, "working hours"));

        // Deletes the address and tags
        trans.begin();
        em.remove(tag1);
        em.remove(tag2);
        em.remove(tag3);
        trans.commit();

        assertNull("Tag should have been deleted", em.find(Tag.class, "working hours"));
    }

    @Test
    public void queryAddresses() {
        Tag tag1 = new Tag("24/7");
        Tag tag2 = new Tag("working hours");
        Tag tag3 = new Tag("night time");
        Tag tag4 = new Tag("week-ends");
        Tag tag5 = new Tag("mind the dog");

        Address address1 = new Address("St James St", "London", "SW14", "UK");
        Address address2 = new Address("Central Side Park", "New York", "7845", "US");
        address2.addTag(tag1);
        address2.addTag(tag2);
        address2.addTag(tag5);
        Address address3 = new Address("Findsbury Avenue", "London", "CE451", "UK");
        address3.addTag(tag2);
        address3.addTag(tag4);
        address3.addTag(tag3);
        Address address4 = new Address("Camden Street", "Brighton", "NW487", "UK");
        address4.addTag(tag2);
        address4.addTag(tag4);
        address4.addTag(tag5);

        // Creates the addresses
        trans.begin();
        em.persist(address1);
        em.persist(address2);
        em.persist(address3);
        em.persist(address4);
        trans.commit();
        Long id = address1.getId();

        Query query;
        List<Address> addresses;

        // Finds all the addresses
        query = em.createQuery("SELECT a FROM Address a");
        addresses = query.getResultList();
        assertEquals(addresses.size(), 4);

        // Finds all the addresses ordered by country
        query = em.createQuery("SELECT a FROM Address a ORDER BY a.country");
        addresses = query.getResultList();
        assertEquals(addresses.size(), 4);

        // Finds all the addresses with a country = UK
        query = em.createQuery("SELECT a FROM Address a WHERE a.country='UK'");
        addresses = query.getResultList();
        assertEquals(addresses.size(), 3);

        // Finds all the addresses with a country = UK (using parameters)
        query = em.createQuery("SELECT a FROM Address a WHERE a.country=:cnty");
        query.setParameter("cnty", "UK");
        addresses = query.getResultList();
        assertEquals(addresses.size(), 3);

        // Finds all the addresses either in London or Brighton
        query = em.createQuery("SELECT a FROM Address a WHERE a.city IN ('London', 'Brighton')");
        addresses = query.getResultList();
        assertEquals(addresses.size(), 3);

        // Finds all the addresses that do not have a tag
        query = em.createQuery("SELECT a FROM Address a WHERE a.tags IS EMPTY");
        addresses = query.getResultList();
        assertEquals(addresses.size(), 1);

        // Finds all the addresses that have at least one tag
        query = em.createQuery("SELECT a FROM Address a WHERE a.tags IS NOT EMPTY");
        addresses = query.getResultList();
        assertEquals(addresses.size(), 3);

        // Finds all the addresses that have a "mind the dog" tag
        query = em.createQuery("SELECT a FROM Address a WHERE :tag MEMBER OF a.tags");
        query.setParameter("tag", tag5);
        addresses = query.getResultList();
        assertEquals(addresses.size(), 2);

        // Deletes the addresses
        trans.begin();
        em.remove(address1);
        em.remove(address2);
        em.remove(address3);
        em.remove(address4);
        em.remove(tag1);
        em.remove(tag2);
        em.remove(tag3);
        em.remove(tag4);
        em.remove(tag5);
        trans.commit();

        assertNull("Address should has been deleted", em.find(Address.class, id));
    }
}