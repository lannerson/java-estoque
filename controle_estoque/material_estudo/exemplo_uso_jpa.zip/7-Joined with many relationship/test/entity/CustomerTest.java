package entity;

import junit.framework.JUnit4TestAdapter;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.persistence.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @author Antonio Goncalves
 */
public class CustomerTest {
    private static String PERSISTENCE_UNIT_NAME = "watermelonPU";
    private static Calendar calendar;

    private EntityManagerFactory emf;
    private EntityManager em;
    private EntityTransaction trans;

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(CustomerTest.class);
    }

    @BeforeClass
    public static void initCalendar() {
        calendar = GregorianCalendar.getInstance();
    }

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        em = emf.createEntityManager();
        trans = em.getTransaction();
    }

    @After
    public void close() {
        em.close();
        emf.close();
    }

    @Test(expected = Exception.class)
    public void wrongQueries() {
        Query query;
        List<Customer> customers;

        // There is no lastname in customer
        query = em.createQuery("SELECT c FROM Customer c WHERE c.lastname='John'");
        customers = query.getResultList();
    }

    @Test
    public void queryCustomers() {
        // Companies
        Company company1 = new Company("Universal", "Mr Universe", 50000, "+154888454", "contact@universal.com");
        company1.setHomeAddress(new Address("World Street", "New York", "7448", "UK"));

        Company company2 = new Company("Sony", "Mr Father", 25000, "+14519454", "contact@sony.com");
        company2.setHomeAddress(new Address("General Alley", "Paris", "75011", "FR"));
        Company company3 = new Company("Warner", "Mr Bross", 10000, "+15465161454", "contact@warner.com");
        company3.setHomeAddress(new Address("Fame Boulevard", "New York", "84487", "US"));
        Company company4 = new Company("BMG", "Mr BMW", 10000, "+44515484", "contact@bmg.com");
        company4.setHomeAddress(new Address("Music Straat", "Berlin", "8542", "GE"));

        // Creates the companys
        trans.begin();
        em.persist(company1);
        em.persist(company2);
        em.persist(company3);
        em.persist(company4);
        trans.commit();

        // Individuals
        calendar.set(1940, 10, 9);
        Individual individual1 = new Individual("John", "Lennon", "+411909", "john@lenon.com", calendar.getTime());
        individual1.setHomeAddress(new Address("Abbey Road", "London", "SW14", "UK"));
        calendar.set(1940, 7, 7);
        Individual individual2 = new Individual("Ringo", "Starr", "+187445", "ringo@star.co.uk", calendar.getTime());
        individual2.setHomeAddress(new Address("Abbey Road", "London", "SW14", "UK"));
        calendar.set(1943, 2, 25);
        Individual individual3 = new Individual("Georges", "Harrison", "+44877899", "georges@harrison.com", calendar.getTime());
        individual3.setHomeAddress(new Address("Abbey Road", "London", "SW14", "US"));
        calendar.set(1942, 6, 18);
        Individual individual4 = new Individual("Paul", "McCartney", "+41871109", "paul@mccartney.co.uk", calendar.getTime());
        individual4.setHomeAddress(new Address("Abbey Road", "London", "SW14", "US"));

        // Creates the individuals
        trans.begin();
        em.persist(individual1);
        em.persist(individual2);
        em.persist(individual3);
        em.persist(individual4);
        trans.commit();

        Query query;
        List<Customer> customers;

        // Finds all the companies
        query = em.createQuery("SELECT c FROM Company c");
        customers = query.getResultList();
        assertEquals(customers.size(), 4);

        // Finds all the individuals
        query = em.createQuery("SELECT i FROM Individual i");
        customers = query.getResultList();
        assertEquals(customers.size(), 4);

        // Finds all the customers
        query = em.createQuery("SELECT c FROM Customer c");
        customers = query.getResultList();
        assertEquals(customers.size(), 8);

        // Finds all the companies with an email address containing co.uk
        query = em.createQuery("SELECT c FROM Company c WHERE c.email LIKE '%co.uk'");
        customers = query.getResultList();
        assertEquals(customers.size(), 0);

        // Finds all the individuals with an email address containing co.uk
        query = em.createQuery("SELECT i FROM Individual i WHERE i.email LIKE '%co.uk'");
        customers = query.getResultList();
        assertEquals(customers.size(), 2);

        // Finds all the customers with an email address containing co.uk
        query = em.createQuery("SELECT c FROM Customer c WHERE c.email LIKE '%co.uk'");
        customers = query.getResultList();
        assertEquals(customers.size(), 2);

        // Finds all the individuals with an email address containing co.uk
        query = em.createQuery("SELECT i FROM Individual i WHERE i.firstname='John'");
        customers = query.getResultList();
        assertEquals(customers.size(), 1);

        // Finds all the companies with a last name = John
        try {
            query = em.createQuery("SELECT c FROM Company c WHERE c.firstname='John'");
            customers = query.getResultList();
            fail();
        } catch (Exception e) {
        }

        // Finds all the customers with an email address containing co.uk
        try {
            query = em.createQuery("SELECT c FROM Customer c WHERE c.firstname='John'");
            customers = query.getResultList();
            fail();
        } catch (Exception e) {
        }

        // Deletes the companys
        trans.begin();
        em.remove(company1);
        em.remove(company2);
        em.remove(company3);
        em.remove(company4);
        trans.commit();

        // Deletes the individuals
        trans.begin();
        em.remove(individual1);
        em.remove(individual2);
        em.remove(individual3);
        em.remove(individual4);
        trans.commit();
    }
}