package entity;

import junit.framework.JUnit4TestAdapter;
import org.junit.After;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 * @author Antonio Goncalves
 */
public class TagTest {
    private static String PERSISTENCE_UNIT_NAME = "watermelonPU";

    private EntityManagerFactory emf;
    private EntityManager em;
    private EntityTransaction trans;

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(TagTest.class);
    }

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        em = emf.createEntityManager();
        trans = em.getTransaction();
    }

    @After
    public void close() {
        em.close();
        emf.close();
    }

    @Test
    public void createTag() {
        Tag tag = new Tag("24/7");

        // Creates a tag
        trans.begin();
        em.persist(tag);
        trans.commit();

        // Finds the tag by primary key
        tag = em.find(Tag.class, "24/7");
        assertNotNull(tag);

        // Deletes the tag
        trans.begin();
        em.remove(tag);
        trans.commit();

        assertNull("Tag should have been deleted", em.find(Tag.class, "24/7"));
    }

    @Test
    public void updateTag() {
        Tag tag = new Tag("24/7");

        // Creates a tag
        trans.begin();
        em.persist(tag);
        trans.commit();

        // Finds the tag by primary key
        tag = em.find(Tag.class, "24/7");
        assertNotNull(tag);

        // Updates the tag
        try {
            trans.begin();
            tag.setName("week-ends");
            trans.commit();
            fail(); // updates are not allowed on primary key
        } catch (Exception e) {
        }

        // Deletes the tag
        trans.begin();
        tag.setName("24/7");
        em.remove(em.merge(tag));
        trans.commit();

        assertNull("Tag should have been deleted", em.find(Tag.class, "24/7"));
    }
    @Test
    public void createDuplicateTag() {
        Tag tag1 = new Tag("24/7");
        Tag tag2 = new Tag("24/7");

        // Creates a tag
        trans.begin();
        em.persist(tag1);
        trans.commit();

        // Creates a second tag with same id
        try {
            trans.begin();
            em.persist(tag2);
            trans.commit();
            fail(); // duplicates are not allowed
        } catch (Exception e) {
            trans.rollback();
        }

        // Deletes the tag
        trans.begin();
        em.remove(em.merge(tag1));
        trans.commit();

        assertNull("Tag should have been deleted", em.find(Tag.class, "24/7"));
    }
}