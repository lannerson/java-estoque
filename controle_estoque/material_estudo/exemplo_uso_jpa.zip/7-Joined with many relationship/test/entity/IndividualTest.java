package entity;

import junit.framework.JUnit4TestAdapter;
import org.junit.After;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.persistence.*;
import java.util.*;

/**
 * @author Antonio Goncalves
 */
public class IndividualTest {
    private static String PERSISTENCE_UNIT_NAME = "watermelonPU";
    private static Calendar calendar;

    private EntityManagerFactory emf;
    private EntityManager em;
    private EntityTransaction trans;

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(IndividualTest.class);
    }

    @BeforeClass
    public static void initCalendar() {
        calendar = GregorianCalendar.getInstance();
    }

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        em = emf.createEntityManager();
        trans = em.getTransaction();
    }

    @After
    public void close() {
        em.close();
        emf.close();
    }

    @Test(expected = Exception.class)
    public void createIndividualWithoutAddress() {
        calendar.set(1940, 10, 9);
        Date dateOfBirth = calendar.getTime();
        Individual individual = new Individual("John", "Lennon", "+411909", "john@lenon.com", dateOfBirth);

        // Creates an individual
        trans.begin();
        em.persist(individual);
        trans.commit();
    }

    @Test
    public void createIndividualWithAddress() {
        calendar.set(1940, 10, 9);
        Date dateOfBirth = calendar.getTime();
        Individual individual = new Individual("John", "Lennon", "+411909", "john@lenon.com", dateOfBirth);
        Address homeAddress = new Address("Abbey Road", "London", "SW14", "UK");
        individual.setHomeAddress(homeAddress);

        // Creates an individual
        trans.begin();
        em.persist(individual);
        trans.commit();
        Long individualId = individual.getId();
        Long addressId = homeAddress.getId();

        // Finds the individual by primary key
        individual = em.find(Individual.class, individualId);
        assertEquals(individual.getEmail(), "john@lenon.com");
        assertEquals(individual.getAge(), 66);
        assertEquals(individual.getHomeAddress().getCountry(), "UK");

        // Updates the individual
        trans.begin();
        individual.setEmail("john@beatles.co.uk");
        homeAddress.setCountry("US");
        trans.commit();

        // Finds the individual by primary key
        individual = em.find(Individual.class, individualId);
        assertEquals(individual.getEmail(), "john@beatles.co.uk");
        assertEquals(individual.getAge(), 66);
        assertEquals(individual.getHomeAddress().getCountry(), "US");

        // Deletes the individual
        trans.begin();
        em.remove(individual);
        trans.commit();

        assertNull("individual should have been deleted", em.find(Individual.class, individualId));
        assertNull("Address should have been deleted", em.find(Address.class, addressId));
    }

    @Test
    public void createIndividualWithDeliveryAddresses() {
        calendar.set(1940, 10, 9);
        Date dateOfBirth = calendar.getTime();
        Individual individual = new Individual("John", "Lennon", "+411909", "john@lenon.com", dateOfBirth);
        // Home address
        Address homeAddress = new Address("Abbey Road", "London", "SW14", "UK");
        individual.setHomeAddress(homeAddress);
        // Delivery addresses
        List<Address> deliveryAddresses = new ArrayList<Address>();
        deliveryAddresses.add(new Address("28 Honey Pie Street", "London", "NE4512", "UK"));
        deliveryAddresses.add(new Address("784 Bungalow Bill", "London", "SW7845", "UK"));
        individual.setDeliveryAddresses(deliveryAddresses);

        // Creates an individual
        trans.begin();
        em.persist(individual);
        trans.commit();
        Long individualId = individual.getId();

        // Finds the individual by primary key
        individual = em.find(Individual.class, individualId);
        assertEquals(individual.getEmail(), "john@lenon.com");
        assertEquals(individual.getHomeAddress().getCountry(), "UK");
        assertEquals(individual.getDeliveryAddresses().size(), 2);

        // Deletes the individual
        trans.begin();
        em.remove(individual);
        trans.commit();

        assertNull("Individual should have been deleted", em.find(Individual.class, individualId));
    }

    @Test
    public void createIndividualWithTaggedAddresses() {
        Tag tag1 = new Tag("working hours");
        Tag tag2 = new Tag("week-ends");
        Tag tag3 = new Tag("mind the dog");

        // Individual
        calendar.set(1940, 10, 9);
        Date dateOfBirth = calendar.getTime();
        Individual individual = new Individual("John", "Lennon", "+411909", "john@lenon.com", dateOfBirth);
        // Tagged Home address
        Address homeAddress = new Address("Abbey Road", "London", "SW14", "UK");
        homeAddress.addTag(tag1);
        homeAddress.addTag(tag2);
        individual.setHomeAddress(homeAddress);
        // Tagged Delivery addresses
        Address deliveryAddress1 = new Address("28 Honey Pie Street", "London", "NE4512", "UK");
        deliveryAddress1.addTag(tag1);
        Address deliveryAddress2 = new Address("784 Bungalow Bill", "London", "SW7845", "UK");
        deliveryAddress2.addTag(tag1);
        deliveryAddress2.addTag(tag2);
        deliveryAddress2.addTag(tag3);
        individual.addDeliveryAddress(deliveryAddress1);
        individual.addDeliveryAddress(deliveryAddress2);

        // Creates a individual
        trans.begin();
        em.persist(individual);
        trans.commit();
        Long individualId = individual.getId();

        // Finds the individual by primary key
        individual = em.find(Individual.class, individualId);
        assertEquals(individual.getEmail(), "john@lenon.com");
        assertEquals(individual.getHomeAddress().getCountry(), "UK");
        assertEquals(individual.getDeliveryAddresses().size(), 2);

        // Makes sure every address is tagged
        for (Address deliveryAddress : individual.getDeliveryAddresses()) {
            assertTrue(deliveryAddress.getTags().size() != 0);
        }

        // Deletes the individual
        trans.begin();
        em.remove(individual);
        trans.commit();

        assertNull("Individual should have been deleted", em.find(Individual.class, individualId));

        // Deletes the tags
        trans.begin();
        em.remove(tag1);
        em.remove(tag2);
        em.remove(tag3);
        trans.commit();
    }

    @Test(expected = IllegalArgumentException.class)
    public void createIndividualWithInvalidPhone() {
        calendar.set(1940, 10, 9);
        Date dateOfBirth = calendar.getTime();
        Individual individual = new Individual("John", "Lennon", "411909", "john@lenon.com", dateOfBirth);

        // Creates an individual
        trans.begin();
        em.persist(individual);
        trans.commit();
    }

    @Test
    public void queryIndividuals() {
        calendar.set(1940, 10, 9);
        Individual individual1 = new Individual("John", "Lennon", "+411909", "john@lenon.com", calendar.getTime());
        individual1.setHomeAddress(new Address("Abbey Road", "London", "SW14", "UK"));
        calendar.set(1940, 7, 7);
        Individual individual2 = new Individual("Ringo", "Starr", "+187445", "ringo@star.com", calendar.getTime());
        individual2.setHomeAddress(new Address("Abbey Road", "London", "SW14", "UK"));
        calendar.set(1943, 2, 25);
        Individual individual3 = new Individual("Georges", "Harrison", "+44877899", "georges@harrison.com", calendar.getTime());
        individual3.setHomeAddress(new Address("Abbey Road", "London", "SW14", "US"));
        calendar.set(1942, 6, 18);
        Individual individual4 = new Individual("Paul", "McCartney", "+41871109", "paul@mccartney.com", calendar.getTime());
        individual4.setHomeAddress(new Address("Abbey Road", "London", "SW14", "US"));

        // Creates the individuals
        trans.begin();
        em.persist(individual1);
        em.persist(individual2);
        em.persist(individual3);
        em.persist(individual4);
        trans.commit();

        Query query;
        List<Individual> individuals;

        // Finds all the individuals
        query = em.createQuery("SELECT i FROM Individual i");
        individuals = query.getResultList();
        assertEquals(individuals.size(), 4);

        // Finds all the individuals ordered by lastname
        query = em.createQuery("SELECT i FROM Individual i ORDER BY i.lastname");
        individuals = query.getResultList();
        assertEquals(individuals.size(), 4);

        // Finds all the individuals with a name = John
        query = em.createQuery("SELECT i FROM Individual i WHERE i.firstname='John'");
        individuals = query.getResultList();
        assertEquals(individuals.size(), 1);

        // Finds all the individuals living in the US
        query = em.createQuery("SELECT i FROM Individual i WHERE i.homeAddress.country='US'");
        individuals = query.getResultList();
        assertEquals(individuals.size(), 2);

        // Finds all the individuals living in the US (using parameters)
        query = em.createQuery("SELECT i FROM Individual i WHERE i.homeAddress.country=:cnty");
        query.setParameter("cnty", "US");
        individuals = query.getResultList();
        assertEquals(individuals.size(), 2);

        // Finds all the individuals with a name containing "Mc" or MC
        query = em.createQuery("SELECT i FROM Individual i WHERE UPPER(i.lastname) LIKE :keyword");
        query.setParameter("keyword", "%MC%");
        individuals = query.getResultList();
        assertEquals(individuals.size(), 1);

        // Deletes the individuals
        trans.begin();
        em.remove(individual1);
        em.remove(individual2);
        em.remove(individual3);
        em.remove(individual4);
        trans.commit();
    }
}