This code illustrates the second article about JPA. You will find 2 sub-directories that contain the code
that changes throughout the article. 

In each sub-directory you will find :
  * a build.xml file that contains the ant tasks to run the test,
  * src directory for the Java source and the persistence.xml file
  * test directory for the JUnit 4.1 test classes

6-Single Table
--------------
As an example you will find just the code of the inheritance mapped using the single table strategy.


7-Joined with many relationship
-------------------------------
Code of the article with the Joind strategy inheritance and the many-to-many relationship.

